<powershell>

$env = "${envTf}"
$NewComputerName = "${NewComputerNameTf}"
$QlikEnterpriseLicenseParameterName = "${QlikEnterpriseLicenseParameterNameTf}"
$QlikAnalyticsLicenseParameterName = "${QlikAnalyticsLicenseParameterNameTf}"
$QlikResponseParameterName = "${QlikResponseParameterNameTf}"
$ACWQlikEnterpriseWindowsConfig = "${ACWQlikEnterpriseWindowsConfigTf}"
$QlikAdminParameterName = "${QlikAdminParameterNameTf}"
$S3BucketName = "s3-rtlh-di-aws-syd-$env-devops"
$awsCliInstallerS3Path = "aws/AWSCLIV2.msi"
$awsCloudWatchAgentInstallerS3Path = "aws/amazon-cloudwatch-agent.msi"
$msodbcsqlInstallerS3Path = "ms/msodbcsql.msi"
$qlikEnterpriseInstallerS3Path = "qlik/QlikEnterpriseManager_2023.11.0.89_X64.exe"
$localCliInstaller = "C:\Temp\AWSCLIV2.msi"
$localCloudWatchAgentInstaller = "C:\Temp\amazon-cloudwatch-agent.msi"
$localMsodbcsqlInstaller = "C:\Temp\msodbcsql.msi"
$localQlikEnterpriseInstaller = "C:\Temp\QlikEnterpriseManager_2023.11.0.89_X64.exe"
$localQlikResponseFile = "C:\Temp\qlik_response_file.iss"
$localQlikEnterpriseLicenseFile = "C:\Temp\qlik_enterprise_license.json"
$localQlikAnalyticsLicenseFile = "C:\Temp\qlik_analytics_license.json"
$silentQlikLogFile = "C:\Temp\silent_x64_install.log"
$qlikInstallPollMaxRetries = 20
$qlikInstallPollretryCount = 0
$qlikInstallPollpollInterval = 15 #seconds
$NewAdminUser = "QlikLocalAdmin"
$CfgPath = "C:\secpol.cfg"

# Rename the computer and restart
Write-Host "Renaming computer to $NewComputerName..."
Rename-Computer -NewName $NewComputerName -Force -Restart

# Wait for the system to reboot before proceeding
Start-Sleep -Seconds 60

# Set up firewall rules for Qlik and SQL communication
Write-Host "Configuring firewall rules for Qlik and DocumentDB..."

# Allow inbound and outbound Qlik communication on ports 443 and 3552
New-NetFirewallRule -DisplayName "Allow Qlik Communication Inbound" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 80, 443, 3552
New-NetFirewallRule -DisplayName "Allow Qlik Communication Outbound" -Direction Outbound -Action Allow -Protocol TCP -LocalPort 80, 443, 3552

# Allow inbound and outbound SQL communication on port 1433
New-NetFirewallRule -DisplayName "Allow DocumentDB Connections Inbound" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 27017
New-NetFirewallRule -DisplayName "Allow DocumentDB Connections Outbound" -Direction Outbound -Action Allow -Protocol TCP -LocalPort 27017

# Create directories if not exist
New-Item -Path "C:\Temp" -ItemType Directory -Force
New-Item -Path "C:\Scripts" -ItemType Directory -Force

# Install AWS CLI
Write-Host "Downloading AWS CLI installer from S3..."
Copy-S3Object -BucketName $S3BucketName -Key $awsCliInstallerS3Path -LocalFile $localCliInstaller

Write-Host "Installing AWS CLI..."
Start-Process msiexec.exe -ArgumentList "/i `"$localCliInstaller`" /quiet" -NoNewWindow -Wait

Write-Host "Adding AWS CLI to PATH..."
$env:Path += ";C:\Program Files\Amazon\AWSCLIV2"

# Install CloudWatch Agent
Write-Host "Downloading CloudWatch Agent installer from S3..."
Copy-S3Object -BucketName $S3BucketName -Key $awsCloudWatchAgentInstallerS3Path -LocalFile $localCloudWatchAgentInstaller

Write-Host "Installing CloudWatch Agent..."
Start-Process msiexec.exe -ArgumentList "/i `"$localCloudWatchAgentInstaller`" /quiet" -NoNewWindow -Wait

# Start CloudWatch Agent using configuration in SSM
Write-Host "Starting CloudWatch Agent with configuration in SSM..."
& "C:\Program Files\Amazon\AmazonCloudWatchAgent\amazon-cloudwatch-agent-ctl.ps1" -a fetch-config -m ec2 -c ssm:$ACWQlikEnterpriseWindowsConfig -s

# Download and install Microsoft ODBC Driver (msodbcsql)
Write-Host "Downloading Microsoft ODBC Driver installer from S3..."
Copy-S3Object -BucketName $S3BucketName -Key $msodbcsqlInstallerS3Path -LocalFile $localMsodbcsqlInstaller

Write-Host "Installing Microsoft ODBC Driver..."
Start-Process msiexec.exe -ArgumentList "/i `"$localMsodbcsqlInstaller`" /quiet" -NoNewWindow -Wait

# Download Qlik Enterprise License from Parameter Store
Write-Host "Downloading Qlik License from Parameter Store..."
$qlikEnterpriseLicenseContent = aws ssm get-parameter --name $QlikEnterpriseLicenseParameterName --with-decryption --query 'Parameter.Value' --output text
[System.IO.File]::WriteAllText($localQlikEnterpriseLicenseFile, $qlikEnterpriseLicenseContent.Trim(), [System.Text.UTF8Encoding]::new($false))

# Download Qlik Analytics License from Parameter Store
Write-Host "Downloading Qlik License from Parameter Store..."
$qlikAnalyticsLicenseContent = aws ssm get-parameter --name $QlikAnalyticsLicenseParameterName --with-decryption --query 'Parameter.Value' --output text
[System.IO.File]::WriteAllText($localQlikAnalyticsLicenseFile, $qlikAnalyticsLicenseContent.Trim(), [System.Text.UTF8Encoding]::new($false))

# Download Qlik Response file from S3
Write-Host "Downloading Qlik Response file from Parameter Store..."
Invoke-Expression "aws ssm get-parameter --name $QlikResponseParameterName --with-decryption --query 'Parameter.Value' --output text > $localQlikResponseFile"

# Setup Qlik local Admin
Write-Host "Creating Qlik Local Admin ..."
$QlikLocalAdminPassword = aws ssm get-parameter --name $QlikAdminParameterName --with-decryption --query 'Parameter.Value'
$QlikLocalAdminPasswordTrim = $QlikLocalAdminPassword.Trim("""")
$SecurePassword = ConvertTo-SecureString $QlikLocalAdminPasswordTrim -AsPlainText -Force
New-LocalUser -Name $NewAdminUser -Password $SecurePassword -FullName "Qlik Local Admin" -Description "Qlik Local Admin"
Write-Host "Adding QlikLocalAdmin to Admin Group ..."
Add-LocalGroupMember -Group "Administrators" -Member $NewAdminUser

# Grant Qlik Local Admin the right to login as a service
Write-Host "Get Config File ..."
secedit /export /cfg C:\secpol.cfg

# Load the config file
$content = Get-Content -Path $CfgPath
$newContent = @()

foreach ($line in $content) {
    # Add each line to the new content array
    $newContent += $line

    # If the line contains SeNetworkLogonRight, add SeServiceLogonRight right after it
    if ($line -match "^SeServiceLogonRight\s*=") {
        Write-Host "Add SeServiceLogonRight to config file..."
        $newContent += "SeServiceLogonRight = *S-1-5-80-0, $NewAdminUser"
    }
}

# Write the updated content back to the file
$newContent | Set-Content -Path $CfgPath

Write-Host "Add Update QlikLocalAdmin with ServiceLogonRight..."
echo y | secedit /configure /db secedit.sdb /cfg C:\secpol.cfg /overwrite

# Clean up
Remove-Item C:\secpol.cfg

# Download and install Qlik Enterprise
Write-Host "Downloading Qlik Enterprise installer from S3..."
Copy-S3Object -BucketName $S3BucketName -Key $qlikEnterpriseInstallerS3Path -LocalFile $localQlikEnterpriseInstaller

Write-Host "Installing Qlik Enterprise..."
Invoke-Expression "& $localQlikEnterpriseInstaller /s /f1$localQlikResponseFile /f2$silentQlikLogFile"

while ($qlikInstallPollRetryCount -lt $qlikInstallPollMaxRetries) {
    if (Test-Path $silentQlikLogFile) {
        $logContent = Get-Content -Path $silentQlikLogFile -Raw
        if ($logContent -match "\[ResponseResult\]\s*ResultCode=0") {
            Write-Host "$qlikInstallPollRetryCount : Qlik Enterprise installation succeeded..."
            $installConfirmed = $true
            break
        }
        elseif ($logContent -match "\[ResponseResult\]\s*ResultCode=-3") {
            Write-Host "$qlikInstallPollRetryCount : Qlik Enterprise installation unable to be determined, continuing with bootstrap regardless..."
            $installConfirmed = $false
            break
        }
    }
    $qlikInstallPollRetryCount++
    Start-Sleep -Seconds $qlikInstallPollpollInterval
    Write-Host "Waiting for Qlik Enterprise to install..."
}

if ($qlikInstallPollRetryCount -ge $qlikInstallPollMaxRetries) {
    Write-Error "Qlik Enterprise installation did not complete successfully within the allotted time, continuing with bootstrap regardless..."
    $installConfirmed = $false
}

# Update Qlik Service to use QlikLocalAdmin
sc.exe config "AttunityEnterpriseManager" obj= ".\QlikLocalAdmin" password= $QlikLocalAdminPasswordTrim

Write-Host "Restarting Enterprise Service..."
Restart-Service -Name "AttunityEnterpriseManager"

# Wait for service to restart (hopefully prevent "Unable to connect to the remote server" error)
Write-Host "Waiting for service to restart..."
Start-Sleep -Seconds 30

# Add aemctl to PATH
Write-Host "Adding Qlik Enterprise Control to PATH..."
$env:Path += ";C:\Program Files\Attunity\Enterprise Manager\bin"

# Get domain to use for authentication
$userAccount = Get-WmiObject -Class Win32_UserAccount | Where-Object { $_.Name -eq $NewAdminUser }
$domain = $userAccount.Domain

# Add Qlik Enterprise User Account to Param Store
Write-Host "Uploading Qlik Enterprise Username to Parameter Store..."
Invoke-Expression "aws ssm put-parameter --name `"/rtlh/di/$env/ec2/qlik-enterprise-username`" --value `"$domain\$NewAdminUser`" --type SecureString --overwrite"

# Bypass SSL certificate validation
Add-Type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class SSLHelper {
    public static void OverrideCertificateValidation() {
        ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCerts);
    }

    public static bool AcceptAllCerts(object sender, X509Certificate cert, X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors) {
        return true;
    }
}
"@

# Call the function to override SSL validation
[SSLHelper]::OverrideCertificateValidation()

# Qlik Enterprise license file paths
$licenseFilePaths = @($localQlikEnterpriseLicenseFile, $localQlikAnalyticsLicenseFile)

# Define the credentials explicitly for NTLM
$creds = New-Object System.Net.NetworkCredential("$NewAdminUser", "$QlikLocalAdminPasswordTrim", "$domain")

# Define a CookieContainer to store cookies
$cookieContainer = New-Object System.Net.CookieContainer

# Create a login request and use NTLM authentication via CredentialCache
Write-Host "Getting Session ID Token..."
$loginRequest = [System.Net.HttpWebRequest]::Create("https://$NewComputerName/attunityenterprisemanager/login/")
$loginRequest.Method = "GET"
$loginRequest.CookieContainer = $cookieContainer

# Set up the CredentialCache with NTLM
$loginRequest.Credentials = New-Object System.Net.CredentialCache
$loginRequest.Credentials.Add($loginRequest.RequestUri, "NTLM", $creds)

# Try to get the Login Session ID and populate the CookieContainer
$loginmaxRetries = 3
$loginretryCount = 0
$loginretryInterval = 15 #seconds
$loginSuccess = $false

while ($loginretryCount -lt $loginmaxRetries -and -not $loginSuccess) {
    try {
        $loginResponse = $loginRequest.GetResponse()
        Write-Host "Login succeeded."

        # Extract the session ID directly from the CookieContainer
        $sessionIdCookie = $cookieContainer.GetCookies("https://$NewComputerName/attunityenterprisemanager") | Where-Object { $_.Name -eq "EnterpriseManager.SessionID" }
        if ($sessionIdCookie) {
            Write-Host "Extracted Session ID successfully"
            $loginSuccess = $true
        } else {
            Write-Host "Session ID not found."
        }
    } catch [System.Net.WebException] {
        Write-Host "Login Error: $($_.Exception.Message)"
        if ($_.Exception.Response) {
            $responseStream = $_.Exception.Response.GetResponseStream()
            $reader = New-Object System.IO.StreamReader($responseStream)
            $responseBody = $reader.ReadToEnd()
            $responseHeaders = $_.Exception.Response.Headers
            $reader.Close()
            Write-Host "Response Body: $responseBody"
            Write-Host "Headers: $responseHeaders"
        }
        $loginretryCount++
        if ($loginretryCount -lt $loginmaxRetries) {
            Write-Host "Retrying login in $loginretryInterval seconds... ($loginretryCount/$loginmaxRetries)"
            Start-Sleep -Seconds $loginretryInterval
        } else {
            Write-Host "Max retries reached. Continuing with the script..."
        }
    }
}

# Try to get XSRF Token
$xsrfRequest = [System.Net.HttpWebRequest]::Create("https://$NewComputerName/attunityenterprisemanager/rest/?action=login")
Write-Host "Getting XSRF Token..."
$xsrfRequest.Method = "GET"
$xsrfRequest.CookieContainer = $cookieContainer

try {
    $xsrfResponse = $xsrfRequest.GetResponse()
    Write-Host "XSRF Token request succeeded."

    # Extract the XSRF-TOKEN from the CookieContainer
    $xsrfTokenCookie = $cookieContainer.GetCookies("https://$NewComputerName/attunityenterprisemanager") | Where-Object { $_.Name -eq "XSRF-TOKEN" }
    if ($xsrfTokenCookie) {
        Write-Host "Extracted XSRF Token successfully"
        $xsrfSuccess = $true
    } else {
        Write-Host "XSRF Token not found."
    }
} catch [System.Net.WebException] {
    Write-Host "XSRF Token Error: $($_.Exception.Message)"
    if ($_.Exception.Response) {
        $responseStream = $_.Exception.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($responseStream)
        $responseBody = $reader.ReadToEnd()
        $responseHeaders = $_.Exception.Response.Headers
        $reader.Close()
        Write-Host "Response Body: $responseBody"
        Write-Host "Headers: $responseHeaders"
    }
}

# Loop through license file, read the content, and send the request
foreach ($filePath in $licenseFilePaths) {
    # Read the JSON content from the file
    $jsonBody = Get-Content -Path $filePath -Raw | Out-String

    # Convert the JSON content to a byte array
    $byteArray = [System.Text.Encoding]::UTF8.GetBytes($jsonBody)

    # Create a new request for each file's content
    $importLicenseRequest = [System.Net.HttpWebRequest]::Create("https://$NewComputerName/attunityenterprisemanager/rest/licenses")
    $importLicenseRequest.Method = "POST"
    $importLicenseRequest.ContentType = "application/octet-stream"
    $importLicenseRequest.CookieContainer = $cookieContainer
    $importLicenseRequest.Headers.Add("X-XSRF-TOKEN", $xsrfTokenCookie.Value)
    $importLicenseRequest.ContentLength = $byteArray.Length

    # Write the JSON body to the request stream
    $importLicenseStream = $importLicenseRequest.GetRequestStream()
    $importLicenseStream.Write($byteArray, 0, $byteArray.Length)
    $importLicenseStream.Close()

    # Send the request and handle the response
    try {
        $importLicenseResponse = $importLicenseRequest.GetResponse()
        $importLicenseResponseStream = $importLicenseResponse.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($importLicenseResponseStream)
        $responseBody = $reader.ReadToEnd()
        $reader.Close()
        $importLicenseResponseStream.Close()

        Write-Host "Import License Response Status Code: $($importLicenseResponse.StatusCode)"
    } catch [System.Net.WebException] {
        Write-Host "Error in Import License Request: $($_.Exception.Message)"
    }
}

# Remove Qlik plain text files
Write-Host "Removing Qlik License and Response file"
Remove-Item -Path $localQlikEnterpriseLicenseFile, $localQlikAnalyticsLicenseFile, $localQlikResponseFile -Force

# If unable to confirm install earlier, run API health check
If ($installConfirmed -eq $false) {
    Write-Host "Qlik Enterprise installation unable to be determined, running health check..."
    $qlikEnterpriseHealthCheck = Invoke-WebRequest -Uri "https://$NewComputerName/attunityenterprisemanager/login" -UseDefaultCredentials
    if ($qlikEnterpriseHealthCheck.StatusDescription -eq "OK") {
        Write-Host "Qlik Enterprise API health check successful."
    } else {
        Write-Host "Qlik Enterprise API health check failed."
    }
}

Write-Host "Bootstrap script completed."
</powershell>
<persist>true</persist>