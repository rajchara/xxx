<powershell>


$env = "${envTf}"
$NewComputerName = "${NewComputerNameTf}"
$QlikLicenseParameterName = "${QlikLicenseParameterNameTf}"
$QlikResponseParameterName = "${QlikResponseParameterNameTf}"
$ACWQlikReplicateWindowsConfig = "${ACWQlikReplicateWindowsConfigTf}"
$QlikAdminParameterName = "${QlikAdminParameterNameTf}"
$QlikEnterpriseHost = "${QlikEnterpriseHostTf}"
$QlikEnterpriseUsernameParameterName = "${QlikEnterpriseUsernameParameterNameTf}"
$QlikEnterprisePasswordParameterName = "${QlikEnterprisePasswordParameterNameTf}"
$S3BucketName = "s3-rtlh-di-aws-syd-$env-devops"
$awsCliInstallerS3Path = "aws/AWSCLIV2.msi"
$awsCloudWatchAgentInstallerS3Path = "aws/amazon-cloudwatch-agent.msi"
$simbaSparkInstallerS3Path ="databricks/Simba Spark 2.7 64-bit.msi"
$msodbcsqlInstallerS3Path = "ms/msodbcsql.msi"
$qlikReplicateInstallerS3Path = "qlik/QlikReplicate_2023.11.0.98_X64.exe"
$qlikLoggingScriptS3Path = "scripts/uploadQlikLogsToS3.ps1"
$localCliInstaller = "C:\Temp\AWSCLIV2.msi"
$localCloudWatchAgentInstaller = "C:\Temp\amazon-cloudwatch-agent.msi"
$localSimbaSparkInstaller = "C:\Temp\Simba Spark 2.7 64-bit.msi"
$localMsodbcsqlInstaller = "C:\Temp\msodbcsql.msi"
$localQlikReplicateInstaller = "C:\Temp\QlikReplicate_2023.11.0.98_X64.exe"
$localQlikLoggingScriptPath = "C:\Scripts\uploadQlikLogsToS3.ps1"
$localQlikResponseFile = "C:\Temp\qlik_response_file.iss"
$localQlikLicenseFile = "C:\Temp\qlik_license.json"
$silentQlikLogFile = "C:\Temp\silent_x64_install.log"
$qlikInstallPollMaxRetries = 20
$qlikInstallPollretryCount = 0
$qlikInstallPollpollInterval = 15 #seconds
$qlikLoggingSchedulerTaskName = "UploadQlikLogsToS3"
$NewAdminUser = "QlikLocalAdmin"
$CfgPath = "C:\secpol.cfg"

# Rename the computer and restart
Write-Host "Renaming computer to $NewComputerName..."
Rename-Computer -NewName $NewComputerName -Force -Restart

# Wait for the system to reboot before proceeding
Start-Sleep -Seconds 60

# Set up firewall rules for Qlik and SQL communication
Write-Host "Configuring firewall rules for Qlik and DocumentDB..."

# Allow inbound and outbound Qlik communication on ports 443 and 3552
New-NetFirewallRule -DisplayName "Allow Qlik Communication Inbound" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 80, 443, 3552
New-NetFirewallRule -DisplayName "Allow Qlik Communication Outbound" -Direction Outbound -Action Allow -Protocol TCP -LocalPort 80, 443, 3552

# Allow inbound and outbound SQL communication on port 1433
New-NetFirewallRule -DisplayName "Allow DocumentDB Connections Inbound" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 27017
New-NetFirewallRule -DisplayName "Allow DocumentDB Connections Outbound" -Direction Outbound -Action Allow -Protocol TCP -LocalPort 27017

# Create directories if not exist
New-Item -Path "C:\Temp" -ItemType Directory -Force
New-Item -Path "C:\Scripts" -ItemType Directory -Force

# Install AWS CLI
Write-Host "Downloading AWS CLI installer from S3..."
Copy-S3Object -BucketName $S3BucketName -Key $awsCliInstallerS3Path -LocalFile $localCliInstaller

Write-Host "Installing AWS CLI..."
Start-Process msiexec.exe -ArgumentList "/i `"$localCliInstaller`" /quiet" -NoNewWindow -Wait

Write-Host "Adding AWS CLI to PATH..."
$env:Path += ";C:\Program Files\Amazon\AWSCLIV2"

# Install CloudWatch Agent
Write-Host "Downloading CloudWatch Agent installer from S3..."
Copy-S3Object -BucketName $S3BucketName -Key $awsCloudWatchAgentInstallerS3Path -LocalFile $localCloudWatchAgentInstaller

Write-Host "Installing CloudWatch Agent..."
Start-Process msiexec.exe -ArgumentList "/i `"$localCloudWatchAgentInstaller`" /quiet" -NoNewWindow -Wait

# Start CloudWatch Agent using configuration in SSM
Write-Host "Starting CloudWatch Agent with configuration in SSM..."
& "C:\Program Files\Amazon\AmazonCloudWatchAgent\amazon-cloudwatch-agent-ctl.ps1" -a fetch-config -m ec2 -c ssm:$ACWQlikReplicateWindowsConfig -s

# Download and install Simba Spark driver
Write-Host "Downloading Simba Spark driver from S3..."
Copy-S3Object -BucketName $S3BucketName -Key $simbaSparkInstallerS3Path -LocalFile $localSimbaSparkInstaller

Write-Host "Installing Simba Spark driver..."
Start-Process msiexec.exe -ArgumentList "/i `"$localSimbaSparkInstaller`" /quiet" -NoNewWindow -Wait

# Download and install Microsoft ODBC Driver (msodbcsql)
Write-Host "Downloading Microsoft ODBC Driver installer from S3..."
Copy-S3Object -BucketName $S3BucketName -Key $msodbcsqlInstallerS3Path -LocalFile $localMsodbcsqlInstaller

Write-Host "Installing Microsoft ODBC Driver..."
Start-Process msiexec.exe -ArgumentList "/i `"$localMsodbcsqlInstaller`" /quiet" -NoNewWindow -Wait

# Download Qlik License from Parameter Store
Write-Host "Downloading Qlik License from Parameter Store..."
$qlikLicenseContent = aws ssm get-parameter --name $QlikLicenseParameterName --with-decryption --query 'Parameter.Value' --output text
[System.IO.File]::WriteAllText($localQlikLicenseFile, $qlikLicenseContent.Trim(), [System.Text.UTF8Encoding]::new($false))

# Download Qlik Response file from S3
Write-Host "Downloading Qlik Response file from Parameter Store..."
Invoke-Expression "aws ssm get-parameter --name $QlikResponseParameterName --with-decryption --query 'Parameter.Value' --output text > $localQlikResponseFile"

# Setup Qlik local Admin
Write-Host "Creating Qlik Local Admin ..."
$QlikLocalAdminPassword = aws ssm get-parameter --name $QlikAdminParameterName --with-decryption --query 'Parameter.Value'
$QlikLocalAdminPasswordTrim = $QlikLocalAdminPassword.Trim("""")
$SecurePassword = ConvertTo-SecureString $QlikLocalAdminPasswordTrim -AsPlainText -Force
New-LocalUser -Name $NewAdminUser -Password $SecurePassword -FullName "Qlik Local Admin" -Description "Qlik Local Admin"
Write-Host "Adding QlikLocalAdmin to Admin Group ..."
Add-LocalGroupMember -Group "Administrators" -Member $NewAdminUser

# Grant Qlik Local Admin the right to login as a service
Write-Host "Get Config File ..."
secedit /export /cfg C:\secpol.cfg

# Load the config file
$content = Get-Content -Path $CfgPath
$newContent = @()

foreach ($line in $content) {
    # Add each line to the new content array
    $newContent += $line

    # If the line contains SeNetworkLogonRight, add SeServiceLogonRight right after it
    if ($line -match "^SeServiceLogonRight\s*=") {
        Write-Host "Add SeServiceLogonRight to config file..."
        $newContent += "SeServiceLogonRight = *S-1-5-80-0, $NewAdminUser"
    }
}

# Write the updated content back to the file
$newContent | Set-Content -Path $CfgPath

Write-Host "Add Update QlikLocalAdmin with SeServiceLogonRight..."
echo y | secedit /configure /db secedit.sdb /cfg C:\secpol.cfg /overwrite

# Clean up
Remove-Item C:\secpol.cfg

# Download and install Qlik Replicate
Write-Host "Downloading Qlik Replicate installer from S3..."
Copy-S3Object -BucketName $S3BucketName -Key $qlikReplicateInstallerS3Path -LocalFile $localQlikReplicateInstaller

Write-Host "Installing Qlik Replicate..."
Invoke-Expression "& $localQlikReplicateInstaller /s /f1$localQlikResponseFile /f2$silentQlikLogFile"

while ($qlikInstallPollRetryCount -lt $qlikInstallPollMaxRetries) {
    if (Test-Path $silentQlikLogFile) {
        $logContent = Get-Content -Path $silentQlikLogFile -Raw
        if ($logContent -match "\[ResponseResult\]\s*ResultCode=0") {
            Write-Host "$qlikInstallPollRetryCount : Qlik Replicate installation succeeded..."
            $installConfirmed = $true
            break
        }
        elseif ($logContent -match "\[ResponseResult\]\s*ResultCode=-3") {
            Write-Host "$qlikInstallPollRetryCount : Qlik Replicate installation unable to be determined, continuing with bootstrap regardless..."
            $installConfirmed = $false
            break
        }
    }
    $qlikInstallPollRetryCount++
    Start-Sleep -Seconds $qlikInstallPollpollInterval
    Write-Host "Waiting for Qlik Replicate to install..."
}

if ($qlikInstallPollRetryCount -ge $qlikInstallPollMaxRetries) {
    Write-Error "Qlik Replicate installation did not complete successfully within the allotted time, continuing with bootstrap regardless..."
    $installConfirmed = $false
}

# Update Qlik Services to use QlikLocalAdmin
sc.exe config "QlikReplicateServer" obj= ".\QlikLocalAdmin" password= $QlikLocalAdminPasswordTrim
sc.exe config "AttunityReplicateConsole" obj= ".\QlikLocalAdmin" password= $QlikLocalAdminPasswordTrim

Write-Host "Restarting Qlik Services"
Restart-Service -Name "QlikReplicateServer"
Restart-Service -Name "AttunityReplicateConsole"

# Add repctl to PATH
Write-Host "Adding Qlik Replicate Control to PATH..."
$env:Path += ";C:\Program Files\Attunity\Replicate\bin"

# Import Qlik license
Write-Host "Importing Qlik License..."
Invoke-Expression "repctl -d `"C:\Program Files\Attunity\Replicate\data`" importlicense license_file=`"$localQlikLicenseFile`""

# Generate and Set Server Password
Write-Host "Generating and setting Qlik Server Password..."
$qlikServerPassword = (repctl genpassword | Select-String -Pattern '"server_password":\s*"([^"]+)"').Matches.Groups[1].Value
Invoke-Expression "repctl setserverpassword `"$qlikServerPassword`""

# Restart Qlik Services
Write-Host "Restarting Qlik Services"
Restart-Service -Name "QlikReplicateServer"
Restart-Service -Name "AttunityReplicateConsole"

# Remove Qlik plain text files
Write-Host "Removing Qlik License and Response file"
Remove-Item -Path $localQlikLicenseFile, $localQlikResponseFile -Force

# Upload Server Password to SSM
Write-Host "Uploading Qlik Server Password to Parameter Store..."
Invoke-Expression "aws ssm put-parameter --name `"/rtlh/di/$env/ec2/$NewComputerName-Server-Password`" --value `"$qlikServerPassword`" --type SecureString --overwrite"

# Download PowerShell script from S3
Write-Host "Downloading Qlik Logging script from S3..."
Copy-S3Object -BucketName $S3BucketName -Key $QlikLoggingScriptS3Path -LocalFile $localQlikLoggingScriptPath

# Set up Qlik Logging Scheduled Tasks
Write-Host "Setting up Qlik Logging to S3 Upload Scheduled Task"
$service = New-Object -ComObject("Schedule.Service")
$service.Connect()
$task = $service.NewTask(0)
$task.RegistrationInfo.Description = "Run Qlik S3 upload script every 5 minutes"
$task.Principal.UserId, $task.Principal.LogonType, $task.Principal.RunLevel = "SYSTEM", 3, 1
$task.Settings.Enabled, $task.Settings.StartWhenAvailable, $task.Settings.DisallowStartIfOnBatteries, $task.Settings.StopIfGoingOnBatteries = $true, $true, $false, $false

# Set action and trigger
$action = $task.Actions.Create(0); $action.Path, $action.Arguments = "PowerShell.exe", "-File `"$localQlikLoggingScriptPath`""
$trigger = $task.Triggers.Create(8); $trigger.Repetition.Interval, $trigger.Repetition.Duration = "PT5M", "P9999D"

# Register the task
$service.GetFolder("\").RegisterTaskDefinition($qlikLoggingSchedulerTaskName, $task, 6, "SYSTEM", $null, 0)

# Start the task immediately
Start-ScheduledTask -TaskName $qlikLoggingSchedulerTaskName

# Bypass SSL certificate validation (to add replicate server to enterprise for monitoring)
Add-Type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class SSLHelper {
    public static void OverrideCertificateValidation() {
        ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCerts);
    }

    public static bool AcceptAllCerts(object sender, X509Certificate cert, X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors) {
        return true;
    }
}
"@

# Call the function to override SSL validation
[SSLHelper]::OverrideCertificateValidation()

# Variables
Write-Host "Downloading Qlik Enterprise Login Information from Parameter Store..."
$qlikEnterpriseUsername = Invoke-Expression "aws ssm get-parameter --name $QlikEnterpriseUsernameParameterName --with-decryption --query 'Parameter.Value' --output text"
$qlikEnterprisePassword = Invoke-Expression "aws ssm get-parameter --name $QlikEnterprisePasswordParameterName --with-decryption --query 'Parameter.Value' --output text"
$qlikEnterpriseAPILoginUrl = "https://$QlikEnterpriseHost/attunityenterprisemanager/api/v1/login"
$qlikEnterpriseAPIAddServerUrl = "https://$QlikEnterpriseHost/attunityenterprisemanager/api/v1/servers/$NewComputerName/def"
$qlikReplicateHostIP = (Get-NetIPAddress | Where-Object { $_.AddressFamily -eq 'IPv4' -and $_.IPAddress -notlike '169.*' -and $_.IPAddress -notlike '127.*'}).IPAddress


# JSON body for adding to Enterprise
$jsonBody = @"
{
    "`$type": "AemReplicateServer",
    "name": "$NewComputerName",
    "description": "$NewComputerName",
    "host": "$qlikReplicateHostIP",
    "port": "3552",
    "username": "admin",
    "password": "$qlikServerPassword",
    "verify_server_certificate": "false",
    "monitored": "true"
}
"@

# Create HttpWebRequest for login
$loginRequest = [System.Net.HttpWebRequest]::Create($qlikEnterpriseAPILoginUrl)
$loginRequest.Method = "GET"

# Encode the username and password for Basic Authentication
$pair = $qlikEnterpriseUsername + ":" + $qlikEnterprisePassword
$encodedCredentials = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($pair))
$loginRequest.Headers.Add("Authorization", "Basic $encodedCredentials")

# Perform the login request and get the session ID
Write-Host "Logging in to the Qlik Enterprise Manager API..."
try {
    $loginResponse = $loginRequest.GetResponse()
    $loginHeaders = $loginResponse.Headers

    # Extract the EnterpriseManager.APISessionID from the headers
    $apiSessionID = $loginHeaders["EnterpriseManager.APISessionID"]

    if ($apiSessionID) {
        Write-Host "Login successful."
    } else {
        Write-Host "EnterpriseManager.APISessionID header not found."
        exit
    }
} catch {
    Write-Host "Error during login: $($_.Exception.Message)"
    exit
}

# Create HttpWebRequest for PUT
$putRequest = [System.Net.HttpWebRequest]::Create($qlikEnterpriseAPIAddServerUrl)
$putRequest.Method = "PUT"
$putRequest.ContentType = "application/json"

# Add the EnterpriseManager.APISessionID header for authentication
$putRequest.Headers.Add("EnterpriseManager.APISessionID", $apiSessionID)

# Write the JSON body to the request stream
$byteArray = [System.Text.Encoding]::UTF8.GetBytes($jsonBody)
$putRequest.ContentLength = $byteArray.Length
$putRequestStream = $putRequest.GetRequestStream()
$putRequestStream.Write($byteArray, 0, $byteArray.Length)
$putRequestStream.Close()

# Get the response from the PUT request
Write-Host "Adding $NewComputerName to Qlik Enterprise for monitoring..."
try {
    $putResponse = $putRequest.GetResponse()
    Write-Host "Successfully added $NewComputerName to Qlik Enterprise. Status Code: $($putResponse.StatusCode)"
} catch {
    Write-Host "Error adding $NewComputerName to Qlik Enterprise: $($_.Exception.Message)"
}

# If unable to confirm install earlier, run API health check
If ($installConfirmed -eq $false) {
    Write-Host "Qlik Replicate installation unable to be determined, running health check..."
    $qlikReplicateHealthCheck = Invoke-WebRequest -Uri "https://$NewComputerName/attunityreplicate/login" -UseDefaultCredentials
    if ($qlikReplicateHealthCheck.StatusDescription -eq "OK") {
        Write-Host "Qlik Replicate API health check successful."
    } else {
        Write-Host "Qlik Replicate API health check failed."
    }
}

Write-Host "Bootstrap script completed."
</powershell>
<persist>true</persist>